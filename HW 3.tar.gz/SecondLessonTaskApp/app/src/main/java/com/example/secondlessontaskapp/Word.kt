package com.example.secondlessontaskapp

data class Word(
    val word: String
)